# CSCI 2270 – Data Structures - Final Project 
<!-- Start by carefully reading the write-up contained in `CSCI2270_Spring22_Project.pdf`.
Please include a thorough description of your program's functionality. Imagine that you are publishing this for users who know nothing about this project. Also, include the names of the team-members/authors. -->
## **Andrew Pleeter and Jaden Feldman**

First, you need to compile the code, be in the scope of the project. If you have cmake locally available, use the following code segment in your terminal.
As long as you're in the scope of the project, `build` will be a directory. Enter the following line-by-line into your terminal. 
```cpp
cd build/

cmake ..

make

./run_app_1
```

**OR** You can compile with STD-17, be in the scope of the project. Use the following code segment in your terminal. Use this in the event where cmake is not available.

```
cd build/
  
g++ -std=c++17 ../app_1/main_1.cpp ../code_1/Blockchain.cpp ../code_1/Block.cpp ../code_1/sha256.cpp ../code_1/Transaction.cpp -o "blockchain"

./blockchain
```
You can compile the project either way, both will execute in the same manner.

## Project Specifications – Buff-CUoin

### Project Description:
This project is a toy version of a working blockchain. It does not consist of any sort of actual currency. It displays the value behind the action of mining a block in a simplistic manner.

The following is conquered in this project:
- [x] Fundamental understanding of transactions in a blockchain
- [x] The idea of security behind each mine (using SHA256 for hashing)
- [x] Understanding the concept between a pending transaction versus a mined transaction
- [x] The implementation of a functional menu with additional options such as viewing the amount in a certain address.


### **Menu Interaction**

* After compilation and prior to the menu interaction on execution, there is a blockchain test that you will see above your menu, these are basic calls to verify that the blockchain is functioning properly.

* The menu will look identical to:

```
======Main Menu======
1. Add a transaction
2. Verify Blockchain
3. Mine Pending Transactions
4. Print transactions
5. View amount in address
6. Quit
```

### Selecting option 1 will prompt you asking for the `src`, `dst`, and `coin` to be transferred, it will look like the following:
*Note: Entering the source as "BFC" will help you generate money.*

```
Source: Jaden
Destination: Andrew
(You currently have: 10 BFC)
Value: 5
Jaden's transaction added to pending
```
In the event where the source does not have the sufficient BFC, the transaction would not be completed and the following is printed:
```
Jaden is too broke for the transaction with Andrew.
```
### Selecting option 2 will verify the hash of every block, it will look like the following if the `previousHash` variable matches up with the calculated hash of each block:
```
Chain is valid: SUCCESS
```
**If** the hashes don't match up (this should never happen), the terminal would look like the following:
```
Chain is invalid: FAILURE
```
### Selecting option 3 will mine the pending transactions into the Blockchain, you will be prompted for your BFC address:
```
Enter your miner address: <INSERT MINER ADDRESS HERE>
```
After you input your miner address, and the mine is successful, the system will automatically give your miner address 10 BFC on the next mine!
### Selecting option 4 will print out all of the transactions throughout the Blockchain, this does not include pending transactions, your output will look similar to the following:
*Note: This list will continuously get larger as more transactions are mined into the blockchain.*
```
(BFC, BFC, 0)
(BFC, BFC, 0)
(BFC, make money by mining, 0)
(BFC, ashutosh, 10)
(BFC, asa, 10)
(ashutosh, maciej, 2)
(BFC, maciej, 10)
(BFC, ashutosh, 10)
...
```
### Selecting option 5 will view the amount in a certain address, you will first be prompted for an address, an example is below:
```
Source: asa
asa currently has 10 BFC.
```
### Selecting option 6 will instantly put you back into your local terminal.
