#include<iostream>
#include <sstream>


#include "Transaction.hpp"
#include "Block.hpp"
#include "sha256.hpp"

using namespace std;
/*
* @param vector<Transaction> transactions
* @param time_t timestamp
* @param string previousHash
* @return none
*/
Block::Block(vector<Transaction> _transactions, time_t _timestamp, string _previousHash) {
    nonce = -1;
    transactions = _transactions;
    previousHash = _previousHash;
    timestamp = _timestamp;
    hash = calculateHash();
}
/*
* @param string previousHash
* @return none
*/
void Block::setPreviousHash(string _previousHash) {
    previousHash = _previousHash;
}
/*
* @param none
* @return vector of transactions with in block
*/
vector<Transaction> Block::getTransactions(){
    return transactions;
}
/*
* @param none
* @return the string of the previous hash
*/
string Block::getPreviousHash(){
    return previousHash;
}
/*
* @param none
* @return The SHA256 of the string format of the individual block.
*/
string Block::calculateHash() {
    return sha256(toString());
}
/*
* Changes the nonce until the calculateHash() function returns a 0 for each index until difficulty
* @param unsigned difficulty
* @return none
*/
void Block::mineBlock(unsigned int difficulty) {
    bool mined = 0;
    string zeroes = "";
    for (unsigned int i = 0; i<difficulty;i++){
        zeroes += '0';
    }
    while(!mined){
        if (calculateHash().substr(0,difficulty) == zeroes) mined = true;
        else nonce++;
    }
}
/*
* @param none
* @return A string with nonce, transactions, previous hash, and the timestamp.
*/
string Block::toString(){
    stringstream data;
    data << "Nonce: " << nonce << "\nTransactions:\n";
    for (unsigned int i = 0; i < transactions.size();i++){
        data << transactions[i].toString() << endl;
    }
    data << "Previous hash: " << previousHash << endl;
    data << "Timestamp: " << timestamp << endl;
    return data.str();
}