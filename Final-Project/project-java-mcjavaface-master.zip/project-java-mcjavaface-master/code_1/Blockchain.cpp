#include<iostream>
#include <sstream>

#include "Transaction.hpp"
#include "Block.hpp"
#include "Blockchain.hpp"
#include<vector>

using namespace std;
/*
* @param none
* @return none
*/
Blockchain::Blockchain() {
    Transaction genesis("BFC","BFC",0);
    pending.push_back(genesis);

    Block gBlock(pending, time(nullptr), "In the beginning..");
    chain.push_back(gBlock);

    Transaction freeMoney("BFC","make money by mining",0);
    pending.push_back(freeMoney);

    difficulty = 4;
    miningReward = 10;
}
/*
* @param none
* @return The lastest block in the chain
*/
Block Blockchain::getLatestBlock() { 
    return chain.back();
}
/*
* Creates a transaction with src, dst, coins, adds it to the pending vector. THIS DOES NOT MODIFY THE CURRENT BLOCKCHAIN
* @param string source
* @param string destination
* @param int coins
* @return none
*/
void Blockchain::addTransaction(string src, string dst, int coins) {
    int srcVal = getBalanceOfAddress(src);
    if (srcVal >= coins){
        Transaction n(src,dst,coins);
        pending.push_back(n);
        if (src != "BFC") cout << src << "'s transaction added to pending\n";
    } else {
        cout << src << " is too broke for the transaction with " << dst << ".\n";
        return;
    }
}
/*
* @param none
* @return true if previous hash matches the calculation of the hash of the previous block. False if they don't match
*/
bool Blockchain::isChainValid() {
    bool valid = false;
    for (int i = 2; i < chain.size();i++){ //traverse through chain starting at index 2
        // cout << chain[i].getPreviousHash() << endl;
        // cout << chain[i-1].calculateHash() << endl;
        if (chain[i].getPreviousHash() == chain[i-1].calculateHash() && chain[i].getPreviousHash()[0] == '0'){
            valid = true;
        } else{ 
            cout << "Invalid Blockchain: " << chain[i].getPreviousHash() << " is not equal to " << chain[i-1].calculateHash() << endl;
            return false;
        }
    }
    return valid;
}
/*
* @param string minerAddress
* @return True as long as function executes properly
*/
bool Blockchain::minePendingTransactions(string minerAddress) {
    // addTransaction("BFC",minerAddress,0); // add 0 to minerAddress just in case it is not found, does not modify values;
    Block newBlock(pending,time(nullptr),getLatestBlock().calculateHash());
    newBlock.mineBlock(difficulty);
    pending.clear();
    chain.push_back(newBlock);
    addTransaction("BFC",minerAddress,miningReward); // new "genesis"
    return true;
}
/*
* @param string address
* @return Balance of the address, 0 if not found or empty.
*/
int Blockchain::getBalanceOfAddress(string address) {
    if (address == "BFC") return 99999999; //BFC is to generate coin, needs to be infinite
    int balance = 0;
    for (unsigned int i = 0; i < chain.size();i++){ //traversal of blocks
        for (unsigned int j = 0; j < chain[i].getTransactions().size();j++){ //traversal of transactions within a block
            if (balance >= 0){
                if(chain[i].getTransactions()[j].getReceiver() == address) {
                    balance += chain[i].getTransactions()[j].getAmount();
                }
                if (chain[i].getTransactions()[j].getSender() == address){
                    balance -= chain[i].getTransactions()[j].getAmount();
                }
            } else balance = 0;
        }
    }
    return balance;
}
/*
* Traverses through each transaction within each block of the chain, function will print as it traverses.
* @param none
* @return none
*/
void Blockchain::prettyPrint() {
    for (unsigned int i = 0; i < chain.size();i++){ //traversal of blocks
        for (unsigned int j = 0; j < chain[i].getTransactions().size(); j++){ //traversal of transactions within a block
            cout << chain[i].getTransactions()[j].toString() << endl;
        }
    }
}